document.getElementById('upload').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        alert("Photo uploaded! Feature preview coming soon.");
    }
});
